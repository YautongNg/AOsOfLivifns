/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package livifwpmmoperator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.DoubleStream;
import java.util.List; 
import java.util.stream.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author localadmin
 */
public class LivifwpmmOperator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        double[][][] MM = {
            {{5.0, 6.0, 1.0, 2.0}, {2.0, 4.0, 1.0, 3.0}, {2.0, 4.0, 1.0, 2.0}},
            {{4.0, 6.0, 1.0, 1.0}, {4.0, 5.0, 1.0, 2.0}, {2.0, 3.0, 1.0, 4.0}},
            {{4.0, 5.0, 2.0, 3.0}, {4.0, 5.0, 1.0, 3.0}, {3.0, 5.0, 2.0, 3.0}},
            {{6.0, 7.0, 1.0, 1.0}, {3.0, 6.0, 1.0, 2.0}, {5.0, 7.0, 1.0, 1.0}},
            
            //C2'
            //{{2.0, 4.0, 2.0, 3.0}, {2.0, 4.0, 1.0, 3.0}, {1.0, 4.0, 2.0, 3.0}},
            //{{4.0, 5.0, 1.0, 2.0}, {1.0, 2.0, 1.0, 4.0}, {3.0, 4.0, 1.0, 2.0}},
            //{{1.0, 3.0, 3.0, 4.0}, {1.0, 2.0, 3.0, 4.0}, {1.0, 3.0, 1.0, 3.0}},
            //{{2.0, 3.0, 2.0, 3.0}, {2.0, 4.0, 1.0, 3.0}, {2.0, 3.0, 2.0, 4.0}},
            
            {{3.0, 5.0, 2.0, 3.0}, {3.0, 5.0, 1.0, 3.0}, {1.0, 4.0, 2.0, 3.0}},
            {{5.0, 6.0, 1.0, 2.0}, {1.0, 2.0, 1.0, 4.0}, {4.0, 5.0, 1.0, 2.0}},
            {{2.0, 4.0, 3.0, 4.0}, {2.0, 3.0, 3.0, 4.0}, {2.0, 4.0, 1.0, 3.0}},
            {{3.0, 4.0, 2.0, 3.0}, {3.0, 5.0, 1.0, 3.0}, {3.0, 4.0, 2.0, 4.0}},
            
            //C3'
            //{{4.0, 5.0, 1.0, 2.0}, {2.0, 3.0, 1.0, 2.0}, {1.0, 2.0, 1.0, 5.0}},
            //{{4.0, 5.0, 1.0, 2.0}, {2.0, 5.0, 1.0, 2.0}, {2.0, 4.0, 1.0, 2.0}},
            //{{2.0, 4.0, 2.0, 3.0}, {1.0, 4.0, 2.0, 3.0}, {2.0, 4.0, 1.0, 3.0}},
            //{{2.0, 4.0, 1.0, 3.0}, {2.0, 3.0, 2.0, 3.0}, {2.0, 4.0, 2.0, 3.0}},
            
            {{5.0, 6.0, 1.0, 2.0}, {3.0, 4.0, 1.0, 2.0}, {2.0, 3.0, 1.0, 5.0}},
            {{5.0, 6.0, 1.0, 2.0}, {3.0, 6.0, 1.0, 2.0}, {3.0, 5.0, 1.0, 2.0}},
            {{3.0, 5.0, 2.0, 3.0}, {2.0, 5.0, 2.0, 3.0}, {3.0, 5.0, 1.0, 3.0}},
            {{3.0, 5.0, 1.0, 3.0}, {3.0, 4.0, 2.0, 3.0}, {3.0, 5.0, 2.0, 3.0}},
            
             
            //C4'
            //{{3.0, 4.0, 2.0, 3.0}, {3.0, 4.0, 1.0, 2.0}, {2.0, 3.0, 2.0, 3.0}},
            //{{1.0, 3.0, 3.0, 4.0}, {2.0, 2.0, 3.0, 5.0}, {1.0, 2.0, 3.0, 4.0}},
            //{{2.0, 4.0, 1.0, 3.0}, {2.0, 2.0, 2.0, 3.0}, {2.0, 4.0, 1.0, 2.0}},
            //{{5.0, 6.0, 1.0, 1.0}, {3.0, 5.0, 1.0, 1.0}, {4.0, 5.0, 1.0, 1.0}}
            
            {{4.0, 5.0, 2.0, 3.0}, {4.0, 5.0, 1.0, 2.0}, {3.0, 4.0, 2.0, 3.0}},
            {{1.0, 3.0, 3.0, 4.0}, {3.0, 3.0, 3.0, 5.0}, {1.0, 2.0, 3.0, 4.0}},
            {{3.0, 5.0, 1.0, 3.0}, {3.0, 3.0, 2.0, 3.0}, {3.0, 5.0, 1.0, 2.0}},
            {{6.0, 7.0, 1.0, 1.0}, {4.0, 6.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 1.0}}                                     
        };
        
        int m = 16;
        int n = 3;
        double q = 1.0;
        double h = 8.0;
        double[] w = {0.243, 0.514, 0.243};
        double[] QQ = {1.0, 0.0, 0.0};
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];              
        double[] SUPP2332 = new double[m];       
        
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(h, MM[i][0][0], MM[i][0][1], MM[i][0][2], MM[i][0][3], MM[i][1][0], MM[i][1][1], MM[i][1][2], MM[i][1][3]);
            SUPP1331[i] = 1 - distanceValue(h, MM[i][0][0], MM[i][0][1], MM[i][0][2], MM[i][0][3], MM[i][2][0], MM[i][2][1], MM[i][2][2], MM[i][2][3]);           
            SUPP2332[i] = 1 - distanceValue(h, MM[i][1][0], MM[i][1][1], MM[i][1][2], MM[i][1][3], MM[i][2][0], MM[i][2][1], MM[i][2][2], MM[i][2][3]);                     
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(SUPP1221[i]));         
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m];               
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i];                  
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(TT5[i]));           
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");           
        double[] W1 = new double[m];
        double[] W2 = new double[m];
        double[] W3 = new double[m];
                      
        for (int i = 0; i < m; i++) {     
            W1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]));
            W2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]));
            W3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(W3[i]));           
        }
                              
        double[][] WW = {
            {W1[0],  W2[0],  W3[0]},
            {W1[1],  W2[1],  W3[1]},
            {W1[2],  W2[2],  W3[2]},
            {W1[3],  W2[3],  W3[3]},                   
            {W1[4],  W2[4],  W3[4]},
            {W1[5],  W2[5],  W3[5]},
            {W1[6],  W2[6],  W3[6]},
            {W1[7],  W2[7],  W3[7]},                   
            {W1[8],  W2[8],  W3[8]},
            {W1[9],  W2[9],  W3[9]},
            {W1[10], W2[10], W3[10]},
            {W1[11], W2[11], W3[11]},                 
            {W1[12], W2[12], W3[12]},
            {W1[13], W2[13], W3[13]},
            {W1[14], W2[14], W3[14]},
            {W1[15], W2[15], W3[15]}
        };
                     
        double[][] RR = new double[m][4];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 4; r++) {
                RR[k][r] = 0.0;
            }           
        }
        LivifwpmmOperator magdm = new LivifwpmmOperator();       
        RR = magdm.LIVIFWMM(m, n, q, h, MM, WW, QQ);
        //RR = magdm.LIVIFWMSM(m, n, q, h, MM, w, 1);
        //RR = magdm.LIVIFWG(m, n, q, h, MM, w);
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("Alpha[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RR[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RR[k][1]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RR[k][2]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RR[k][3]));
        }
              
        int mmm = 4;
        int nnn = 4;              
        double[] wa = {0.4, 0.25, 0.2, 0.15};
        //double[] QQQ = {0.5, 1.0, 1.5, 2.0};
        double[] QQQ = {1.0, 2.0, 3.0, 0.0};
        double[][][] MMM = {
            {{RR[0][0], RR[0][1], RR[0][2], RR[0][3]}, {RR[1][0], RR[1][1], RR[1][2], RR[1][3]}, {RR[2][0], RR[2][1], RR[2][2], RR[2][3]}, {RR[3][0], RR[3][1], RR[3][2], RR[3][3]}},
            {{RR[4][0], RR[4][1], RR[4][2], RR[4][3]}, {RR[5][0], RR[5][1], RR[5][2], RR[5][3]}, {RR[6][0], RR[6][1], RR[6][2], RR[6][3]}, {RR[7][0], RR[7][1], RR[7][2], RR[7][3]}},
            {{RR[8][0], RR[8][1], RR[8][2], RR[8][3]}, {RR[9][0], RR[9][1], RR[9][2], RR[9][3]}, {RR[10][0], RR[10][1], RR[10][2], RR[10][3]}, {RR[11][0], RR[11][1], RR[11][2], RR[11][3]}},
            {{RR[12][0], RR[12][1], RR[12][2], RR[12][3]}, {RR[13][0], RR[13][1], RR[13][2], RR[13][3]}, {RR[14][0], RR[14][1], RR[14][2], RR[14][3]}, {RR[15][0], RR[15][1], RR[15][2], RR[15][3]}}
        };
        double[] S1221 = new double[mmm];
        double[] S1331 = new double[mmm];
        double[] S1441 = new double[mmm];      
        double[] S2332 = new double[mmm];
        double[] S2442 = new double[mmm];       
        double[] S3443 = new double[mmm];        
        for (int i = 0; i < mmm; i++) {          
            S1221[i] = 1 - distanceValue(h, MMM[i][0][0], MMM[i][0][1], MMM[i][0][2], MMM[i][0][3], MMM[i][1][0], MMM[i][1][1], MMM[i][1][2], MMM[i][1][3]);
            S1331[i] = 1 - distanceValue(h, MMM[i][0][0], MMM[i][0][1], MMM[i][0][2], MMM[i][0][3], MMM[i][2][0], MMM[i][2][1], MMM[i][2][2], MMM[i][2][3]);
            S1441[i] = 1 - distanceValue(h, MMM[i][0][0], MMM[i][0][1], MMM[i][0][2], MMM[i][0][3], MMM[i][3][0], MMM[i][3][1], MMM[i][3][2], MMM[i][3][3]);                    
            S2332[i] = 1 - distanceValue(h, MMM[i][1][0], MMM[i][1][1], MMM[i][1][2], MMM[i][1][3], MMM[i][2][0], MMM[i][2][1], MMM[i][2][2], MMM[i][2][3]);
            S2442[i] = 1 - distanceValue(h, MMM[i][1][0], MMM[i][1][1], MMM[i][1][2], MMM[i][1][3], MMM[i][3][0], MMM[i][3][1], MMM[i][3][2], MMM[i][3][3]);                 
            S3443[i] = 1 - distanceValue(h, MMM[i][2][0], MMM[i][2][1], MMM[i][2][2], MMM[i][2][3], MMM[i][3][0], MMM[i][3][1], MMM[i][3][2], MMM[i][3][3]);                   
        }
        double[] TTT1 = new double[mmm];
        double[] TTT2 = new double[mmm]; 
        double[] TTT3 = new double[mmm]; 
        double[] TTT4 = new double[mmm];        
        for (int i = 0; i < mmm; i++) {          
            TTT1[i] = S1221[i] + S1331[i] + S1441[i]; 
            TTT2[i] = S1221[i] + S2332[i] + S2442[i];
            TTT3[i] = S1331[i] + S2332[i] + S3443[i];
            TTT4[i] = S1441[i] + S2442[i] + S3443[i];                      
        }
        double[] WWW1 = new double[mmm];
        double[] WWW2 = new double[mmm];
        double[] WWW3 = new double[mmm];
        double[] WWW4 = new double[mmm];  
             
        for (int i = 0; i < mmm; i++) {     
            WWW1[i] = (wa[0]*(1.0 + TTT1[i])) / (wa[0]*(1.0 + TTT1[i]) + wa[1]*(1.0 + TTT2[i]) + wa[2]*(1.0 + TTT3[i]) + wa[3]*(1.0 + TTT4[i]));
            WWW2[i] = (wa[1]*(1.0 + TTT2[i])) / (wa[0]*(1.0 + TTT1[i]) + wa[1]*(1.0 + TTT2[i]) + wa[2]*(1.0 + TTT3[i]) + wa[3]*(1.0 + TTT4[i]));
            WWW3[i] = (wa[2]*(1.0 + TTT3[i])) / (wa[0]*(1.0 + TTT1[i]) + wa[1]*(1.0 + TTT2[i]) + wa[2]*(1.0 + TTT3[i]) + wa[3]*(1.0 + TTT4[i]));
            WWW4[i] = (wa[3]*(1.0 + TTT4[i])) / (wa[0]*(1.0 + TTT1[i]) + wa[1]*(1.0 + TTT2[i]) + wa[2]*(1.0 + TTT3[i]) + wa[3]*(1.0 + TTT4[i]));           
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(WWW4[i]));
        }
           
        double[][] WWW = {
            {WWW1[0], WWW2[0], WWW3[0], WWW4[0]},
            {WWW1[1], WWW2[1], WWW3[1], WWW4[1]},
            {WWW1[2], WWW2[2], WWW3[2], WWW4[2]},
            {WWW1[3], WWW2[3], WWW3[3], WWW4[3]}                  
        };

        double[][] RRR = new double[mmm][4];
        for (int k = 0; k < mmm; k++) {
            for (int r = 0; r < 4; r++) {
                RRR[k][r] = 0.0;
            }           
        }
        
        RRR = magdm.LIVIFWMM(mmm, nnn, q, h, MMM, WWW, QQQ);
        //RRR = magdm.LIVIFWMSM(mmm, nnn, q, h, MMM, wa, 3);
        //RRR = magdm.LIVIFWG(mmm, nnn, q, h, MMM, wa);
        
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("CV[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][1]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][2]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][3]));
        }
        
        double[] scoreValue = new double[mmm];                 
        scoreValue = magdm.getScoreValue(mmm, h, RRR);
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("Score[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(scoreValue[k]));
        }
        double[] accuracyValue = new double[mmm];                 
        accuracyValue = magdm.getAccuracyValue(mmm, RRR);
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("Accuracy[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(accuracyValue[k]));
        }
        
	ArrayIndexComparator comparator = new ArrayIndexComparator(scoreValue, accuracyValue);
	Integer[] indexes = comparator.createIndexArray();
	Arrays.sort(indexes, comparator);
	for(int i = 0; i < indexes.length; i++) {           
            int index = indexes[i]+1;
            System.out.print("A[" + index + "] > ");
        }
        
        
        /*//Example in Liu and Qin 2019
        double[][][] MMM = {
            {{6.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}, {4.0, 5.0, 1.0, 3.0}, {6.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}},
            {{4.0, 5.0, 1.0, 2.0}, {5.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}, {5.0, 6.0, 1.0, 2.0}, {6.0, 7.0, 1.0, 1.0}},
            {{5.0, 6.0, 1.0, 2.0}, {4.0, 5.0, 2.0, 3.0}, {6.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}, {3.0, 4.0, 3.0, 4.0}},
            {{4.0, 5.0, 2.0, 3.0}, {6.0, 7.0, 1.0, 1.0}, {4.0, 5.0, 2.0, 3.0}, {4.0, 6.0, 1.0, 2.0}, {3.0, 4.0, 3.0, 4.0}}
        };
        double[][][] MM = {
            {{6.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}, {4.0, 5.0, 1.0, 3.0}, {6.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}},
            {{4.0, 5.0, 1.0, 2.0}, {5.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}, {5.0, 6.0, 1.0, 2.0}, {6.0, 7.0, 1.0, 1.0}},
            {{5.0, 6.0, 1.0, 2.0}, {4.0, 5.0, 2.0, 3.0}, {6.0, 7.0, 1.0, 1.0}, {5.0, 6.0, 1.0, 2.0}, {3.0, 4.0, 3.0, 4.0}},
            {{4.0, 5.0, 2.0, 3.0}, {6.0, 7.0, 1.0, 1.0}, {4.0, 5.0, 2.0, 3.0}, {4.0, 6.0, 1.0, 2.0}, {3.0, 4.0, 3.0, 4.0}}
        }; 
        
        int mmm = 4;
        int m = 4;
        int nnn = 5;
        int n = 5;
        double q = 1.0;
        double h = 8.0;
        double[] wa = {0.2, 0.25, 0.15, 0.18, 0.22};
        double[] w = {0.2, 0.25, 0.15, 0.18, 0.22};
        
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        double[] SUPP4554 = new double[m];
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(h, MM[i][0][0], MM[i][0][1], MM[i][0][2], MM[i][0][3], MM[i][1][0], MM[i][1][1], MM[i][1][2], MM[i][1][3]);
            SUPP1331[i] = 1 - distanceValue(h, MM[i][0][0], MM[i][0][1], MM[i][0][2], MM[i][0][3], MM[i][2][0], MM[i][2][1], MM[i][2][2], MM[i][2][3]);
            SUPP1441[i] = 1 - distanceValue(h, MM[i][0][0], MM[i][0][1], MM[i][0][2], MM[i][0][3], MM[i][3][0], MM[i][3][1], MM[i][3][2], MM[i][3][3]);
            SUPP1551[i] = 1 - distanceValue(h, MM[i][0][0], MM[i][0][1], MM[i][0][2], MM[i][0][3], MM[i][4][0], MM[i][4][1], MM[i][4][2], MM[i][4][3]);
            SUPP2332[i] = 1 - distanceValue(h, MM[i][1][0], MM[i][1][1], MM[i][1][2], MM[i][1][3], MM[i][2][0], MM[i][2][1], MM[i][2][2], MM[i][2][3]);
            SUPP2442[i] = 1 - distanceValue(h, MM[i][1][0], MM[i][1][1], MM[i][1][2], MM[i][1][3], MM[i][3][0], MM[i][3][1], MM[i][3][2], MM[i][3][3]);
            SUPP2552[i] = 1 - distanceValue(h, MM[i][1][0], MM[i][1][1], MM[i][1][2], MM[i][1][3], MM[i][4][0], MM[i][4][1], MM[i][4][2], MM[i][4][3]);
            SUPP3443[i] = 1 - distanceValue(h, MM[i][2][0], MM[i][2][1], MM[i][2][2], MM[i][2][3], MM[i][3][0], MM[i][3][1], MM[i][3][2], MM[i][3][3]);
            SUPP3553[i] = 1 - distanceValue(h, MM[i][2][0], MM[i][2][1], MM[i][2][2], MM[i][2][3], MM[i][4][0], MM[i][4][1], MM[i][4][2], MM[i][4][3]);
            SUPP4554[i] = 1 - distanceValue(h, MM[i][3][0], MM[i][3][1], MM[i][3][2], MM[i][3][3], MM[i][4][0], MM[i][4][1], MM[i][4][2], MM[i][4][3]);
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(SUPP4554[i]));         
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i];
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(TT5[i]));           
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");           
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
              
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {     
            w1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w4[i] = (w[3]*(1.0 + TT4[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w5[i] = (w[4]*(1.0 + TT5[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w5[i]));           
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
         double[][] www = {
            {w1[0],  w2[0], w3[0], w4[0], w5[0]},
            {w1[1],  w2[1], w3[1], w4[1], w5[1]},
            {w1[2],  w2[2], w3[2], w4[2], w5[2]},
            {w1[3],  w2[3], w3[3], w4[3], w5[3]}        
        };    
        
        double[][] RRR = new double[mmm][4];
        for (int k = 0; k < mmm; k++) {
            for (int r = 0; r < 4; r++) {
                RRR[k][r] = 0.0;
            }           
        }
        double[] QQQ = {1.0, 2.0, 3.0, 0.0, 0.0};
        LivifwpmmOperator magdm = new LivifwpmmOperator(); 
        RRR = magdm.LIVIFWMM(mmm, nnn, q, h, MMM, www, QQQ);
        //RRR = magdm.LIVIFWMSM(mmm, nnn, q, h, MMM, wa, 3);
        //RRR = magdm.LIVIFWG(mmm, nnn, q, h, MMM, wa);
        
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("MN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][1]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][2]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(RRR[k][3]));
        }
        
        double[] scoreValue = new double[mmm];                 
        scoreValue = magdm.getScoreValue(mmm, h, RRR);
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("Score[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(scoreValue[k]));
        }
        double[] accuracyValue = new double[mmm];                 
        accuracyValue = magdm.getAccuracyValue(mmm, RRR);
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("Accuracy[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(accuracyValue[k]));
        }
        
	ArrayIndexComparator comparator = new ArrayIndexComparator(scoreValue, accuracyValue);
	Integer[] indexes = comparator.createIndexArray();
	Arrays.sort(indexes, comparator);
	for(int i = 0; i < indexes.length; i++) {           
            int index = indexes[i]+1;
            System.out.print("A[" + index + "] > ");
        }*/       
    }
    
    public static void permutation(ArrayList<Integer> s, ArrayList<Integer> rs, ArrayList<ArrayList<Integer>> res) {                     
        if(s.size()== 1) {               
            rs.add(s.get(0));  
            ArrayList<Integer> tmp=new ArrayList<Integer>();  
            for(Integer a:rs)  
                tmp.add(a);
            res.add(tmp);
            rs.remove(rs.size()-1);                              
        } else {                 
            for(int i=0;i<s.size();i++) {                    
                rs.add(s.get(i));   
                ArrayList<Integer> tmp=new ArrayList<Integer>();  
                for(Integer a:s)  
                     tmp.add(a);  
                tmp.remove(i);  
                permutation(tmp,rs,res);  
                rs.remove(rs.size()-1);                
            }  
        }                     
    }  
     
    public static double factorial1(int number) {
        double result = 1;
        for (int factor = 2; factor <= number; factor++) {
            result *= factor;
        }
        return 1.0/result;
    }

    public double[][] LIVIFWMM(int m, int n, double q, double h, double[][][] theta, double[][] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0; i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][4];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;  
            result[k][2] = 1.0;
            result[k][3] = 1.0;
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                double product2 = 1.0;
                double product3 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q)/h, n*w[k][curidx]), delta[j]);
                    product1 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][1], q)/h, n*w[k][curidx]), delta[j]);
                    product2 *= Math.pow((1.0 - Math.pow(theta[k][curidx][2]/h, q*n*w[k][curidx])), delta[j]);
                    product3 *= Math.pow((1.0 - Math.pow(theta[k][curidx][3]/h, q*n*w[k][curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
                result[k][2] *= (1.0 - product2);
                result[k][3] *= (1.0 - product3);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = h * Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = h * Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1/q);
            result[k][2] = h * Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][2], factorial1(n)), sumdelta1), 1.0/q); 
            result[k][3] = h * Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][3], factorial1(n)), sumdelta1), 1.0/q);
        }        
        return result;       
    }
    
    // Garg and Kumar 2019
    public double[][] LIVIFWA(int m, int n, double q, double h, double[][][] theta, double[] w) {
        double[][] resultOfLIVIFWA = new double[m][4];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 4; r++) {
                resultOfLIVIFWA[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][4];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 4; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                
                product[k][0] = product[k][0] * Math.pow(1 - Math.pow(theta[k][i][0]/h, q), w[i]);
                product[k][1] = product[k][1] * Math.pow(1 - Math.pow(theta[k][i][1]/h, q), w[i]);
                product[k][2] = product[k][2] * Math.pow(theta[k][i][2]/h, w[i]);                        
                product[k][3] = product[k][3] * Math.pow(theta[k][i][3]/h, w[i]);    
            }
            resultOfLIVIFWA[k][0] = h * Math.pow(1 - product[k][0], 1.0/q);
            resultOfLIVIFWA[k][1] = h * Math.pow(1 - product[k][1], 1.0/q);
            resultOfLIVIFWA[k][2] = h * product[k][2];
            resultOfLIVIFWA[k][3] = h * product[k][3];
        }
        return resultOfLIVIFWA;
    }
    
    //Garg and Kumar 2019
    public double[][] LIVIFWG(int m, int n, double q, double h, double[][][] theta, double[] w) {
        double[][] resultOfLIVIFWG = new double[m][4];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 4; r++) {
                resultOfLIVIFWG[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][4];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 4; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                
                product[k][0] = product[k][0] * Math.pow(theta[k][i][0]/h, w[i]);
                product[k][1] = product[k][1] * Math.pow(theta[k][i][1]/h, w[i]);
                product[k][2] = product[k][2] * Math.pow(1 - Math.pow(theta[k][i][2]/h, q), w[i]);                        
                product[k][3] = product[k][3] * Math.pow(1 - Math.pow(theta[k][i][3]/h, q), w[i]);     
            }
            resultOfLIVIFWG[k][0] = h * product[k][0];
            resultOfLIVIFWG[k][1] = h * product[k][1];
            resultOfLIVIFWG[k][2] = h * Math.pow(1 - product[k][2], 1.0/q);
            resultOfLIVIFWG[k][3] = h * Math.pow(1 - product[k][3], 1.0/q);
        }
        return resultOfLIVIFWG;
    }
    
    // Liu and Qin, 2019
    public double[][] LIVIFWMSM(int m, int n, double q, double h, double[][][] theta, double[] w, int kk) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0; i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);   
        double[] delta = new double[n];
        for (int j = 0; j < kk; j++) {
            delta[j] = 1.0;
        }
        for (int jj = kk; jj < n; jj++) {
            delta[jj] = 0.0;
        }
        double[][] result = new double[m][4];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;
            result[k][2] = 1.0;
            result[k][3] = 1.0;
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                double product2 = 1.0;
                double product3 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q)/h, n*w[curidx]), delta[j]);
                    product1 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][1], q)/h, n*w[curidx]), delta[j]);                  
                    product2 *= Math.pow((1.0 - Math.pow(theta[k][curidx][2]/h, q*n*w[curidx])), delta[j]);
                    product3 *= Math.pow((1.0 - Math.pow(theta[k][curidx][3]/h, q*n*w[curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
                result[k][2] *= (1.0 - product2);
                result[k][3] *= (1.0 - product3);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = h * Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = h * Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1/q);           
            result[k][2] = h * Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][2], factorial1(n)), sumdelta1), 1.0/q);
            result[k][3] = h * Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][3], factorial1(n)), sumdelta1), 1.0/q);
        }        
        return result;             
    }
    
    public static double distanceValue(double h, double a1, double b1, double c1, double d1, double a2, double b2, double c2, double d2) {
        double distanceValue = 0.0;
        distanceValue = (Math.abs(a1-a2) + Math.abs(b1-b2) + Math.abs(c1-c2) + Math.abs(d1-d2))/(4.0*h);     
        return distanceValue;
    }
    
    // Define a function to compute the score value of a q-ROFN
    public double[] getScoreValue(int m, double h, double[][] theta) {
        double[] scoreValue = new double[m];
        for (int k = 0; k < m; k++) {
            scoreValue[k] = (2.0*h + theta[k][0] + theta[k][1] - theta[k][2] - theta[k][3]) / 4.0;
        }
        return scoreValue;
    } 
    
    // Define a function to compute the accuracy value of a q-ROFN
    public double[] getAccuracyValue(int m, double[][] theta) {
        double[] accuracyValue = new double[m];
        for (int k = 0; k < m; k++) {
            accuracyValue[k] = (theta[k][0] + theta[k][1] + theta[k][2] + theta[k][3]) / 2.0;
        }
        return accuracyValue;
    }
}
